import logging.config
import logging

import requests

from thoughtspot.models.metadata import Metadata
from thoughtspot.models.auth import Session


_log = logging.getLogger(__name__)


class ThoughtSpot:

    def __init__(self, ts_config):
        self.config = ts_config
        self.http = requests.Session()

        # set up logging
        logging.getLogger('urllib3').setLevel(logging.ERROR)

        try:
            logging.config.dictConfig(ts_config.logging)
            _log.info(f'set up provided logger at level {ts_config.logging}')
        except ValueError:
            logging.basicConfig(
                format='[%(levelname)s - %(asctime)s] '
                       '[%(name)s - %(module)s.%(funcName)s %(lineno)d] '
                       '%(message)s',
                level=getattr(logging, ts_config.logging['level'])
            )

            level = logging.getLevelName(logging.getLogger('root').getEffectiveLevel())
            _log.info(f'set up the default logger at level {level}')

        # set up our session
        self.http.headers.update({'X-Requested-By': 'ThoughtSpot'})

        if ts_config.thoughtspot.disable_ssl:
            self.http.verify = False
            requests.packages.urllib3.disable_warnings()

        # add in all our model endpoints
        self.auth = Session(self)
        self.metadata = Metadata(self)

    @property
    def host(self):
        """
        URL of ThoughtSpot.
        """
        return self.config.thoughtspot.host

    def __enter__(self):
        self.auth.login()
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        self.auth.logout()
