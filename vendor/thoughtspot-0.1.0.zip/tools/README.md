# Tools

ThoughtSpot Tools are a collection of different tools which have been developed against
the API or various tooling used to support the ThoughtSpot platform. TS tools are
typically developed to help customers or employees be more agile between ThoughtSpot
releases and prioritzation schedules.

Many of the tools are written in Python and require a Python environment in order to
function. Almost all of the Python tools are not required to live on the same host as
the ThoughtSpot cluster, but should have access to the cluster.

Each directory under this one will be devoted to a single tool, as if it were a separate
python package. This allows tools to grow and scale in complexity organically. Please
visit each tool directly to find it's README.md and supporting documentation.
