
# Contributing to TS Tools

**Thank you for contributing to TS Tools!**

When contributing to this repository, please first discuss the change you wish to make 
via [issue][repo-new-issue] or [email][ps-na-email] with the owners of this repository before making a change.

We love your input! We want to make contributing to this project as easy and transparent
as possible, whether it's:

 - Reporting a bug
 - Discussing the current state of the code
 - Submitting a fix
 - Proposing new features

## Communication

 - [Create an Issue][repo-new-issue]
 - [Email][ps-na-email]

## Contributions

The process is straight-forward.

 1. Fork the CS Tools [git repository][repo-master].
 2. Write the code for your feature/fix.
    - if you're writing Python code, consider [setting up a virtual environment][repo-hack-venv].
    - if you're contributing a new feature, write tests to validate the feature works.
 3. Ensure all the tests pass.
 4. Create a [Pull Request][repo-pull-request] against the [dev][repo-dev] branch of TS Tools.

## Pull requests are always welcome
Not sure if that typo is worth a pull request? Found a bug and know how to fix it? Do
it! We will appreciate it.

[ps-na-email]: mailto:ps-na@thoughtspot.com
[repo-new-issue]: https://github.com/thoughtspot/ts_tools/issues/new
[repo-pull-request]: https://github.com/thoughtspot/ts_tools/compare
[repo-master]: https://github.com/thoughtspot/ts_tools/tree/master
[repo-dev]: https://github.com/thoughtspot/ts_tools/tree/dev
[repo-hack-venv]: ./best-practices/virtual-environment.md
