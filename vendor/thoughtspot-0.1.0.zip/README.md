<p align="center">
  <a href="https://www.thoughtspot.com/">
    <img width="350" height="208" src="./docs/img/logo_black.svg" alt='ThoughtSpot'>
  </a>
</p>

TS Tools is an initiative by the Customer Success team at ThoughtSpot to standardize,
collect, and streamline various tools that are in use with clients today. This
repository is introduced to coordinate ancillary engineering asks across clients that
are capable within ThoughtSpot but not included as a built-in part of the platform yet.
This allows the field team to be more agile when aiding customers, and customers gain
the benefit of having additional functionality.

## Getting Started

To clone and work this library, you'll want to have [Git][install-git] and
[Python 3.6.1][install-python] or greater installed on your computer. Then, create a
virtual environment and activate it. <sup>([Don't know how to do that][bp-venv]?)</sup>

From your command line:
```console
$ pip install git+https://github.com/thoughtspot/cs_tools.git

-or-

$ poetry add git+https://github.com/thoughtspot/cs_tools.git
$ poetry install
```

That's it!

P.S. - for extra credit, don't forget to check out our [best practices][bp-main]!

## Our Tools

Note: All tools currently live alongside the ThoughtSpot library as an implementation
detail. All CS tools are installed as part of the Github CS Tools library. They do not
live under the `/thoughtspot` directory so that they may be shared directly. All tools
do however, depend on the ThoughtSpot library in order to function properly.

For further reading about tool structure, please see the [tools README][tools-readme].

[install-git]: https://git-scm.com/downloads
[install-python]: https://www.python.org/downloads
[bp-main]: ./best-practices/
[bp-venv]: ./best-practices/virtual-environment.md
[tools-readme]: ./tools/README.md
