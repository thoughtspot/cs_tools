from thoughtspot_internal.models._base import TSPrivate
