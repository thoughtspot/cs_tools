# import performance data

./sharding_diagnostics.sh

./sharding_diagnostics_load.sh


