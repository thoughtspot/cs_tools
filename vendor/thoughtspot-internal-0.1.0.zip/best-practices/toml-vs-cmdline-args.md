# Tool Parameters

## TOML vs Command Line Arguments

Lorem ipsum...
